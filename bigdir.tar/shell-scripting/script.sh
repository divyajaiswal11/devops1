myvar='hello world'
echo $myvar
